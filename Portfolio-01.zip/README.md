# Responsive Portfolio

# My Awesome Project
This is my portfolio showing my projects and skills. Check out!

<a href="https://www.lucasperrotaroriz.com/" target="_blank">**Link to project:** </a>

## Desktop View


## Mobile View


## How It's Made:
**Tech used:** HTML, CSS, JavaScript, MixupJS, ScrollRevealJS, EmailJS.

## Optimizations

In the future i will make the website simpler and more concise.

## Lessons Learned:

* Mobile first approach
* BEM and code organization
* Implementing dark mode
* Mobile navigation animation
* Image optimization
* Contact form that works with EmailJS

<!-- 
## Examples:
Take a look at these couple examples that I have in my own portfolio:

**Palettable:** https://github.com/alecortega/palettable

**Twitter Battle:** https://github.com/alecortega/twitter-battle

**Patch Panel:** https://github.com/alecortega/patch-panel

-->
